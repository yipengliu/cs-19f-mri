function [ xRec,sRec,iter ] = OMMP( meas,S,D)
% Reconstruct signal using the OMMP algorithm
%   Input:  meas = measured signal
%           S = sensing matrix (size: MxN)
%           D = dictionary (size: NxN
%   Output: xRec = reconstructed signal
%           sRec = coefficient vector
%           iter = number of iterations performed
%
%   Based on:
%   Zhiqiang Xu
%   The performance of orthogonal multi-matching pursuit under RIP
%   2012

% Change variables according to paper notation
phi = S*D;
[m,N] = size(phi);
u = meas; % measurement

% Indices selected per iteration
% In OMP, amount = 1
amount = 4;

% Initialize
omega = []; % support
phiOmega = []; % elements from phi corresponding to the support
r = u; % residual = measurement
k = 1; % counter
refNorm = inf; % stopping criterion
iter = 0; % iteration counter

% do until the norm of the residual is small enough (compared to the
% norm of the measurement, value 0.05 chosen arbitrarily
while refNorm > 0.05
    
    iter = iter + 1;
    
    % find columns in dictionary most corresponding to residual
    [maxVal,n] = maxN(abs(phi'*r),amount,'normal');
    n = n'; % transpose indices vector
    omega = [omega n]; % add column numbers to support
    phiOmega(:,k:k+amount-1) = phi(:,n); % create matrix with phi vectors corresponding to support

    % backslash operator returns the least squares solution of the
    % system of linear equations phiOmega*x = u
    x = phiOmega \ u;

    % compute residual
    r = u - phiOmega*x;
    
    % increment k
    k = k+amount;
    
    % extra stopping criterion
    if refNorm <= norm(r,2)/norm(u,2)
        break
    end
    
    % reference norm
    refNorm = norm(r,2)/norm(u,2);
     
end

% Create coefficient vector
coeff = zeros(N,1);
coeff(omega) = x;
sRec = coeff; % Return coefficient vector in sRec

% Calculate reconstructed signal
xRec = D*coeff; % Return reconstructed signal in xRec

end