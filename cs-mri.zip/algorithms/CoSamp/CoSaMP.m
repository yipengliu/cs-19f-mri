function [ xRec,sRec,iter ] = CoSaMP( meas,S,D)
% Reconstruct using the OMP algorithm
%   Input:  meas = measured signal
%           l = original signal length
%           S = sensing matrix (size: MxN)
%           D = dictionary (size: NxN
%           K = expected sparsity
%   Output: xRec = reconstructed signal
%
%   Based on:
%   Joel A. Tropp and Stephen J. Wright
%   Computational Methods for Sparse Solution of Linear Inverse Problems
%   Proceedings of the IEEE, Vol. 98, No. 6, June 2010

% Change variables according to paper notation
phi = S*D;
[m,N] = size(phi);
phiOmega = [];
u = meas; % measurement

% Initialize
omega = []; % support
r = u; % residual
k = 1; % counter
alfa = 0.1; % tuning parameter (s*alfa atoms selected per iteration)
s = 120; % indices retained
amount = round(s*alfa);
refNorm = inf;

% % do until the norm of the residual is small enough (compared to the
% % norm of the measurement
% h=figure;

iter = 0;

while refNorm > 0.02 
    
    iter = iter + 1;
    
    % find best approximating column in dictionary
    [maxVal,n] = maxN(abs(phi'*r),amount,'normal');
    n = n';
    omega = [omega n];
    phiOmega(:,k:k+amount-1) = phi(:,n);

    % backslash operator returns the least squares solution of the
    % system of linear equations phiOmega*x = u
    x = phiOmega \ u;
    
    if length(x) > s
        [xPruned,ind] = maxN(x,s,'abs');
        x = zeros(length(x),1);
        x(ind) = xPruned;
    end

    % compute residual
    r = u - phiOmega*x;
    
    % increment k
    k = k+amount;
    
    % extra stopping criterion
    if refNorm <= norm(r,2)/norm(u,2)
        break
    end
    
	refNorm = norm(r,2)/norm(u,2);
%    sparsity = length(find(x));
    
%     % Create coefficient vector
%     coeff = zeros(N,1);
%     coeff(omega) = x;

%     % Calculate reconstructed signal
%     xRec = D'*coeff;

end

% Create coefficient vector
coeff = zeros(N,1);
coeff(omega) = x;

% Calculate reconstructed signal
xRec = D*coeff;

sRec = coeff;

end
