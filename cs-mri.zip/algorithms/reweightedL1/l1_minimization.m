function x = l1_minimization(Y, Phi, w, delta)
if nargin < 5
    delta = 0;
end
[M, N] = size(Phi);

if delta == 0
    A = [eye(N), -eye(N); -eye(N), -eye(N)];
    b = zeros( 2 * N, 1);
    Aeq = [Phi, zeros(M,N)];
    beq = Y;
    f = [zeros( 1, N), w'];
    
    opts = optimset('LargeScale', 'off','Simplex','on');
    temp = linprog( f, A, b, Aeq, beq, [], [], [], opts);
    x = temp( 1 : N );
else
    
%     A = [eye(N), -eye(N), zeros(N,M); -eye(N), -eye(N), zeros(N,M)];
%     b = zeros( 2 * N, 1);
%     
%     A_add = [-Phi, zeros(M, N), -eye(M)];
%     b_add = -Y;
%     A = [A; A_add];
%     b = [b; b_add];
%     
%     A_add = [Phi, zeros(M, N), -eye(M)];
%     b_add = Y;
%     A = [A; A_add];
%     b = [b; b_add];    
%     f = [zeros( 1, N), w', delta*ones(1,M)];

    A = [eye(N), -eye(N); -eye(N), -eye(N)];
    b = zeros( 2 * N, 1);

    A_add = [-Phi'*Phi, zeros(M, N)];
    b_add = -Phi'*Y + delta;
    A = [A; A_add];
    b = [b; b_add];
    
    A_add = [Phi'*Phi, zeros(M, N)];
    b_add = Phi'*Y + delta;
    A = [A; A_add];
    b = [b; b_add];
    
    
    f = [zeros( 1, N), w'];

    
    opts = optimset('LargeScale', 'off','Simplex','on');
    temp = linprog( f, A, b, [], [], [], [], [], opts);
    x = temp( 1 : N );    
end