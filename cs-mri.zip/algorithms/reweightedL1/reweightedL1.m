
function [x, theta] = reweightedL1(y, Phi, Psi,N)

% fprintf(' ------ l1 - reweighted method------ \n')
delta = 0.005;
w = ones( N, 1 );
A=Phi*Psi;
theta0  = l1_minimization(y, A, w, delta);
num_x = length(find(abs(theta0)>0.0001))

epsilon = 0.008;
theta_k = theta0 ;

for ii = 1 : 5
    w = 1./(abs(theta_k) + epsilon);
    theta_k_1 = l1_minimization(y, A, w, delta);
    num_x = length(find(abs(theta_k_1)>0.0001))
    if norm(theta_k - theta_k_1) < 0.0001
        break
    else
        theta_k = theta_k_1;
    end    
end
theta=theta_k_1;
x  = Psi*theta;