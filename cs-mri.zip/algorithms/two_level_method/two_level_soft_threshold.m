function x = two_evel_soft_threshold(Y, Phi, tau)
[M, N] = size(Phi);
K = ceil(M/10);

% step = 1/norm(Phi)/2;

x_k_1 =  Phi'*Y;
x_k = zeros(size(x_k_1));


while norm(x_k - x_k_1)/norm(x_k) > 10^-4
    x_k = x_k_1;
    x_k_1 = x_k + Phi'*(Y - Phi*x_k);
   
    
    [~,indx] = sort(-abs(x_k_1));
    indx_I = indx( 1 : K );
    w = ones( N, 1 );
    w(indx_I) = 0;
    
    x_k_1 = wthresh(x_k_1, 's', tau*w);
end
x = x_k_1;